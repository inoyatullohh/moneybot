from aiogram import Router, types
from keyboards import main_menu

router = Router()

@router.message(lambda msg: msg.text.lower() in ["menu", "asosiy", "🏠"])
async def show_menu(message: types.Message):
    await message.answer("📋 Asosiy menyu:", reply_markup=main_menu())
